package com.fuslion;



public class Employee1 {
	
	private int EmployeeId;
	private String EmployeeName;
	private String EmployeeRole;
	private double EmployeeSalary;
	
	private Department1 department;
	
	public Employee1() {
		
	}




	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}




	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}




	public void setEmployeeRole(String employeeRole) {
		EmployeeRole = employeeRole;
	}




	public void setEmployeeSalary(double employeeSalary) {
		EmployeeSalary = employeeSalary;
	}




	public void setDepartment(Department1 department) {
		this.department = department;
	}




	@Override
	public String toString() {
		return "Employee1 [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", EmployeeRole="
				+ EmployeeRole + ", EmployeeSalary=" + EmployeeSalary + ", department=" + department + "]";
	}
	
	
	
	

}
