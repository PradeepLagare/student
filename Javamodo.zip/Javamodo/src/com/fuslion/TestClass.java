package com.fuslion;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class TestClass {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringBeansConfiguaration.class);

		Department1 department = (Department1)context.getBean("department10");
		department.setDepartmentId(1253);
		department.setDepartementName("Python");
		
		System.out.println(department.toString());
		
		Employee1 employee = (Employee1)context.getBean("employee10");
		employee.setEmployeeId(4523);
		employee.setEmployeeName("Omker Patil");
		employee.setEmployeeRole("Web Developer");
		employee.setEmployeeSalary(12568.56);
		employee.setDepartment(department);
		
		System.out.println(employee);
		

	}

	}


