package com.fuslion;

public class Department1 {
	

	private int DepartmentId;
	private String DepartementName;
	
	
	public Department1() {
		
	}
	

	public void setDepartmentId(int departmentId) {
		DepartmentId = departmentId;
	}


	public void setDepartementName(String departementName) {
		DepartementName = departementName;
	}


	@Override
	public String toString() {
		return "Department1 [DepartmentId=" + DepartmentId + ", DepartementName=" + DepartementName + "]";
	}

	
}
