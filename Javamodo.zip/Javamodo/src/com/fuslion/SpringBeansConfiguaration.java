package com.fuslion;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringBeansConfiguaration {

	@Bean(name="employee10")
	public Employee1 getEmployeeBean()
	{
		return new Employee1();
	}
	
	@Bean(name="department10")
	public Department1 getDepartmentBean()
	{
		return new Department1();
	}
	
}
