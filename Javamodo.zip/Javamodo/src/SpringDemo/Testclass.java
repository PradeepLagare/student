package SpringDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Testclass {

	public static void main(String[] args) {

		
		ApplicationContext context = new ClassPathXmlApplicationContext("Customer.xml");
		
		Customer customer = (Customer)context.getBean("customer1");
		System.out.println(customer.toString());
		
	}

}
