package ConstructorlnjectionJavaConfig;

public class Employee {
	
	private int EmployeeId;
	private String EmployeeName;
	private String EmployeeRole;
	private double EmployeeSalary;
	
	public Department departemnt;

	public Employee(int employeeId, String employeeName, String employeeRole, double employeeSalary,
			Department departemnt) {
		super();
		EmployeeId = employeeId;
		EmployeeName = employeeName;
		EmployeeRole = employeeRole;
		EmployeeSalary = employeeSalary;
		this.departemnt = departemnt;
	}

	@Override
	public String toString() {
		return "Employee [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", EmployeeRole="
				+ EmployeeRole + ", EmployeeSalary=" + EmployeeSalary + ", departemnt=" + departemnt + "]";
	}
	
	
}
